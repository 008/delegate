#define main(ac,av) md5_main(ac,av)
#include "mddriver.c"
