void regdummy(){
}
