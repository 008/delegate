

int INHERENT_fchmod(){ return 1; }
