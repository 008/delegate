#include "ystring.h"
FileSize getSysinfo(const char *name){
	return -1;
}
