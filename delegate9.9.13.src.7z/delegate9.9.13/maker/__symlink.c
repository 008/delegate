int WITH_symlink(){ return 1; }
