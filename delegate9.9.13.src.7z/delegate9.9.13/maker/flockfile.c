#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
void flockfile(FILE *fp){
}
void funlockfile(FILE *fp){
}
#ifdef __cplusplus
}
#endif
