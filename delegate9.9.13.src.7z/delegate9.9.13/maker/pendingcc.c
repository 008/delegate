#include <stdio.h>
int pendingcc(FILE *fp){
	return -1;
}
