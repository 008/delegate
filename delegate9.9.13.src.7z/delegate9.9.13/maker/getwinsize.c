int getwinsize(int fd,int *row,int *col){
	return -1;
}
int setwinsize(int fd,int row,int col){
	return -1;
}
