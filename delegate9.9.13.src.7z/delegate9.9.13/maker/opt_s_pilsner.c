#include "dglib.h"

int pilsner_main(int ac,const char *av[]){
	NOSRC_warn("pilsner","");
	return -1;
}
int pilsner(DGC*ctx,const char *src,char *dst,int dsz){
	return -1;
}
