char *ERR_error_string_n(int code,char str[],int siz)
{
	*str = 0;
	return str;
}
