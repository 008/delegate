#if defined(__hppa__)

#ifdef __cplusplus
extern "C" {
#endif

	void allow_unaligned_data_access(){}

#ifdef __cplusplus
}
#endif

#endif
