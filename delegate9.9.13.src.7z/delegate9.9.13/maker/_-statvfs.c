/*
 * statvfs() is available but the specification mismatches with __statvfs.c
 */
#include "statvfs.c"
