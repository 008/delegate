long gethostid(void){
	return 0;
}
