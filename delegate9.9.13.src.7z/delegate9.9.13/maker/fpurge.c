#include "ystring.h"
int fpurge(FILE *fp){
	return 0;
}
