int SUBST_nice = 1;

int nice(int inc){
	return -1;
}
