

int INHERENT_lstat(){ return 1; }
