#define X_SAL unsigned int
#include "socklen_s.c"
