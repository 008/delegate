

int INHERENT_fchown(){ return 1; }
