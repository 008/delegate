/* for __osf__ even with mkcpp */
#include "__pthread_create.c"
