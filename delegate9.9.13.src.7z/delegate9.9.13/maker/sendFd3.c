const char *ver_sendFd(){ return "sendFd3"; };

int sendFd(int sockfd,int fd,int pid){
	return -1;
}
int recvFd(int sockfd){
	return -1;
}

