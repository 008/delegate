/* for Solaris9 ? */
#undef __cplusplus
#define RTYPE int
#include "unsetenv.c"
