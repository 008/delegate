int _ForkptyX(int *pty,char *name,void *mode,void *size){
	return -1;
}
int _Forkpty(int *pty,char *name){
	return -1;
}
