int netsh_main(int ac,const char *av[]){
	return -1;
}
