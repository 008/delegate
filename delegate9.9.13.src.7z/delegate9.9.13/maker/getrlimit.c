int expand_fdset(int setsize)
{
	return 256;
}
int expand_stack(int setsize)
{
	return -1;
}
