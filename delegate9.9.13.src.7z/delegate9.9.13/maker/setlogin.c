int setlogin(const char *name){
	return -1;
}
