#include "vsocket.h"
#include "dglib.h"

int spinach_main(int ac,const char *av[]){
	NOSRC_warn("spinach","");
	return -1;
}
int spinach(DGC *Conn,FILE *fc,FILE *tc){
	return 0;
}

int startCCSV(DGC *Conn){
	return -1;
}
int destroyCCSV(PCStr(what),DGC *Conn,int svsock){
	return -1;
}
int connectViaCCSV(int sock,SAP addr,int leng,int timeout,PVStr(cstat)){
	return -1;
}
int waitCCSV(DGC *Conn,int msec){
	return -1;
}
int service_ecc(DGC *Conn,int sock,int port){
	return -1;
}
