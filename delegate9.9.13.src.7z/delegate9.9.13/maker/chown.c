int SUBST_chown = 1;

int chown(const char *path,int uid,int gid)
{
	return -1;
}
