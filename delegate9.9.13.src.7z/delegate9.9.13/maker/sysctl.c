#include "ystring.h"
FileSize getSysctl(const char *name){
	return -1;
}
