#include "dglib.h"
const char *OPT_S_stls;

typedef struct DGCtx Connection;
int beManInTheMiddle(Connection *Conn,FILE *tc,FILE *fc){
	NOSRC_warn("beManInTheMiddle","");
	return -1;
}
