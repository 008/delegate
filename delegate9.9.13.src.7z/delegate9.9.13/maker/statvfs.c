int Fstype(const char *path,char type[])
{
	*type = 0;
	return -1;
}
