const char *DELEGATE_srcsign(){
return
"\n{SRCSIGN=9.9.2-pre3:20090215114817+0900:9fd8879636f9934b:\
Author@DeleGate.ORG:\
s7F+zgs2D6yvuw+K1c3xJg4C9AJLSTuOGi2TAIPVQ52AwW0aqwRdJl3vME+/AaJpt3gKiH7b\r\n\
od6uyzyUFdkSIOgaTrMMdJBYBvCm0s7YhOpqCePnThu4e4RnMYTTpsI693BTt80KFXHwz4X3\r\n\
KO5W8Q4noFBPBme3yWwx/frGMMw=\r\n\
}\n"+10;
}
