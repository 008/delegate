#ifndef _DGCTX_H
#define _DGCTX_H

#ifndef DGCTX
#define DGCtx DGCtx00
typedef struct DGCtx DGC;
#define DGCTX	DGC*
#endif

#endif
