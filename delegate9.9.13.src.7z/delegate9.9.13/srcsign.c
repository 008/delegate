const char *DELEGATE_srcsign(){
return
"\n{SRCSIGN=9.9.13:20141031194217+0900:6fdc87e522763a5e:\
Author@DeleGate.ORG:\
hPtX79eyOAnj9pjzcHNLBa2+1uhqjZszJ1UM7y4wXOikCGaUA4aQmK+kuq0QC/hng7lskzc9\r\n\
aIjEgOpDo5KF1odrli0RsQJI8nkGIWAW3uYxIFD70pwSAGNteRViGCmbIdO95QJfTjgTfKhp\r\n\
TQV3AYSDfyHF4li8dewmsd+oRrA=\r\n\
}\n"+10;
}
const char *DELEGATE_SrcSign(){
return
"\n{SrcSign=9.9.2-pre3:20090215114817+0900:9fd8879636f9934b:\
Author@DeleGate.ORG:\
s7F+zgs2D6yvuw+K1c3xJg4C9AJLSTuOGi2TAIPVQ52AwW0aqwRdJl3vME+/AaJpt3gKiH7b\r\n\
od6uyzyUFdkSIOgaTrMMdJBYBvCm0s7YhOpqCePnThu4e4RnMYTTpsI693BTt80KFXHwz4X3\r\n\
KO5W8Q4noFBPBme3yWwx/frGMMw=\r\n\
}\n"+10;
}
